#!/usr/bin/env python
# encoding: utf8
# Artificial Intelligence, UBI 2018-19
# Modified by: Students names and numbers

import time
import rospy
from std_msgs.msg import String
from nav_msgs.msg import Odometry


x_ant = 0
y_ant = 0
obj_ant = ''
#Array de 11 elementos (11 salas), em que cada posiçao é um dicionario
salas=[{},{},{},{},{},{},{},{},{},{},{},{}]
sala={}
room_ant=1
rm=1
#Variaveis globais para os caminhos e para o tempo
paths ={}
times ={}
#t_in inicialmente com o tempo inicial
t_in=time.time()
#---------------------------------------------------------------

# odometry callback
def callback(data):
	global x_ant, y_ant,rm,times,t_in
	x=data.pose.pose.position.x
	y=data.pose.pose.position.y
	# show coordinates only when they change
	if x != x_ant or y != y_ant:
		print " x=%.1f y=%.1f" % (x,y)
	x_ant = x
	y_ant = y
        #atributes current room <>
	global room_ant
	if x > -1:
 		if y < 1.5 : room=1
		elif y<6.6 : room=2
		else: room=3
	elif x > -6:
 		if y < 1.5 : room=4
		else: room=5
	elif x > -11:
 		if y < 1.5 : room=6
		elif y<6.6 : room=7
		else: room=8
	else:
 		if y < 1.5 : room=9
		elif y<6.6 : room=10
		else: room=11
	
	#caso a sala atual!= sala anterior
	if room!= rm:
		adiciona_paths(str(room),str(rm))#adiciona caminhos sempre que muda de sala 
		if(str(rm-1) not in times.keys()):#adiciona o tempo a sala		
			times[str(rm-1)]=time.time()-t_in
			t_in=time.time()
		else:#adicion o tempo decorrido ao tempo ja adicionado anteriormente
			times[str(rm-1)]=times[str(rm-1)]+time.time()-t_in
			t_in=time.time()
 		room_ant=rm#atualiza as variaveis das salas
		rm=room
		print " room = %d" % room
	


# ---------------------------------------------------------------
#8-Probabilidade de encontar uma cadeira dado que ja encontrou um livro
def probbook():
	global salas
	count_book=0
	count_book_chair=0	
	for i in range (len( salas)):#Para todas as salas
		if("book" in salas[i].keys()):#que contenha pelo menos um livro
			count_book+=1#adiciona um a contagem de livros 
			if("chair" in salas[i].keys()):#caso nessa sala exista pelo menos uma cadeira
				count_book_chair+=1#aumenta a contagem de salas onde existem cadeiras e livros
	#calcula probabilidades
	prob_A_B=1.0*count_book_chair/len(salas)
	prob_A=1.0*count_book/len(salas)
	return 1.0*prob_A_B/prob_A

#-------6---Paths
#adicionar caminhos
def adiciona_paths(nodo_1,nodo_2):
  global paths
  if(nodo_1 in paths.keys()):#caso a primeira sala exista nas keys() do paths
    if(nodo_2 not in paths[nodo_1]):#e nao exista a segunda sala no array dos vertices adjacentes da primeira
      paths[nodo_1].append(nodo_2)#adiciona a segunda sala
  else:
    paths[nodo_1]=[nodo_2]
  if(nodo_2 in paths.keys()):#vice-versa para a segunda sala
    if(nodo_1 not in paths[nodo_2]):
      paths[nodo_2].append(nodo_1)
  else:
    paths[nodo_2]=[nodo_1]

#devolve caminhos de 'a' a 'b'
def dfs_caminhos(grafo, inicio, fim):
    pilha = [(inicio, [inicio])]
    while pilha:
        vertice, caminho = pilha.pop()
        for proximo in set(grafo[vertice]) - set(caminho):
            if proximo == fim:
                yield caminho + [proximo]
            else:
                pilha.append((proximo, caminho + [proximo]))



# ---------------------------------------------------------------
#Funçao que devolve a sala onde o objeto tem o nome indicado
def find_sala(type_obj,name):
	global salas
	for i in range(len(salas)):
		if(type_obj in salas[i].keys()):
			if name in salas[i][type_obj]:
				return i+1
	return -1

# encontra as salas em contenham o maior numero de objetos iguais a sala indicada
#depois dessas salas verifica qual o objeto com maior probabilidade
def proxobj(sala):
	global salas
	proximidade={}
	obj={}
	for i in range(len (salas)):#procura as salas com maior proximidade, isto é, com um maior numero de objetos iguais
		if i != sala:
			l=set(salas[i].keys()).intersection(set(salas[sala].keys()))
			if(len (l)!=0):
				m=0			
				for x in l:
					m+=len(salas[sala][x])-len(salas[i][x])
				if (m>=0):
			 		if(m in proximidade.keys()):
						proximidade[m].append(i)
					else:
						proximidade[m]=[i]
				else:
					if(x in obj.keys()):
						obj[x]=obj[x]+0-m
					else:
						obj[x]=0-m
					m=0
					if(m in proximidade.keys()):
						proximidade[m].append(i)
					else:
						proximidade[m]=[i]
	maxprox=proximidade.keys()[0]
	#com as salas com maior proximidade vou contar o numero que cada objeto aparece nestas salas
	for i in proximidade[maxprox]:
		for n in salas[i].keys():
			if n not in salas[sala].keys():
				if n in obj.keys():				
					obj[n]=obj[n]+len(salas[i][n])
				else:obj[n]=len(salas[i][n])
	maxobj=0
	obje=[]
	#verifico o objeto que aparece mais vezes
	for j in obj.keys():
		if obj[j] > maxobj:
			maxobj=obj[j]
			obje=[j]
		elif obj[j] == maxobj:
			obje.append(j)
			maxobj=obj[j]
	print "O possivel objeto é:" + obj[0]


#--------------------------------------------------------------
# 3- What is the prob of finding 10 books in this world?
def nr_of_seen_objs():#Conta quantos objetos viu no mundo
	global salas
    	nr_objs = 0    
	for i in range(len(salas)):
		for key in salas[i].keys():
			nr_objs =nr_objs + len(salas[i][key]) 
    	return (nr_objs)

def prob_ten_books():
    	global salas
    	count_book = 0        
	for i in range(len(salas)):
        	if "book" in salas[i].keys():
			count_book =count_book +  len(salas[i]["book"] ):#Conta quantos livros viu no mundo 
	return( ( 1.0*count_book / (nr_of_seen_objs()) ) ** (10-count_book))#calcula a probabilidade



#atribuiçao do tipo de sala
	
def roomtype(obj,sala):
	#variaveis das salas pre definidas no enunciado
	wr=['chair']
	str1=['chair','table','book','person']
	str2=['chair','table','book']
	compr=['table','computer','chair']
	meetr=['table','chair']
	#dois conjuntos sao iguais quando a uniao e a interseçao entre estes dois conjuntos e igual
	if set(wr).intersection(set(obj))==set(wr).union(set(obj)):
		print "Waiting Room"
	elif set(str1).intersection(set(obj))==set(str1).union(set(obj)) or set(str2).intersection(set(obj))==set(str2).union(set(obj)):
		print "Study Room"
	elif set(compr).intersection(set(obj))==set(compr).union(set(obj)):
		print "Computer Room"
	elif set(meetr).intersection(set(obj))==set(meetr).union(set(obj)):
		if len(sala['table'])==1:		
			print "Meeting Room"
		else:
			print "Generic Room"
	else:
		print "Generic Room"
# print dos objetos de uma sala
def objects_in_room(room):
	obj=salas[room-1].keys()
	if len(obj)==0:
		print "nao visualizou objetos"
	else:
		for i in range(len(obj)):
			print obj[i]

# print quantos objetos diferentes 
def diftypes():
	global salas
	for i in range (len( salas)):
		if i == 0:
			obj=salas[i].keys()
		else: 
	 	  	x=salas[i].keys()
			for j in range(len(x)):
				if x[j] not in obj:
					obj.append(x[j])
	print len(obj)
# object_recognition callback
def callback1(data):
	global obj_ant
	global room_ant
	global salas
	global dala,rm
	obj = data.data
	if obj != obj_ant and data.data != "":
		print "object is %s" % data.data
		for i in range(len(data.data.split(","))):
			obj1=data.data.split(",")[i]
			obj_types=salas[rm-1].keys()
			if obj1.split("_",1)[0] in obj_types:#atribuiçao dos objetos as respetivas salas
				if obj1.split("_",1)[1] not in salas[rm-1][obj1.split("_",1)[0]]:
	 				salas[rm-1][obj1.split("_",1)[0]].append(obj1.split("_",1)[1])
			else:
				salas[rm-1][obj1.split("_",1)[0]]=[obj1.split("_",1)[1]]
	obj_ant = obj
	
        
		
# ---------------------------------------------------------------
# questions_keyboard callback
def callback2(data):
	global room_ant,paths,rm,time
	print "question is %s" % data.data
	if data.data == "1":
          	diftypes()
	elif data.data == "2":
          	objects_in_room(room_ant)
	elif data.data == "3":
		try:
		    print prob_ten_books()
		except:
		    print "0.0"
	elif data.data == "5":
		med=0
		for i in times.keys():
			med=med+times[i]#Soma dos tempos conhecidos
		try:
			if "4" in times.keys():#caso a sala 5 tenha tempo 
				print "O tempo estimado é :" + str((med/(len(times.keys())+1))*12)#o tempo calculado é a soma a dividir pelo numero de salas percorridas +1(sala 5 vale por duas) multiplicada por 11 +1(sala 5 vale por duas)
			else:
				print "O tempo estimado é :" + str((med/len(times.keys()))*12)#o tempo calculado é a soma a dividir pelo numero de salas percorridas multiplicada por 11 +1(sala 5 vale por duas)
		except:
			print("Tempo ainda nao e possivel de prever")
	elif data.data == "7":
		x=find_sala("person","mary")
		if x==-1:
			print "Mary ainda nao foi descoberta"
		else:
			roomtype(salas[x-1].keys(),salas[x-1])
	elif data.data == "6":
		try:
          		caminhos=list(dfs_caminhos(paths,'1',str(rm)))
			print len(caminhos)
			
		except:
			print "Ainda nao existem caminhos possiveis"
	elif data.data == "8":
		try:
          		print probbook() + "%"
		except: print "0.0%"
	elif data.data == "4":
		try:
			x=find_sala("person","joe")
			if x==-1:
				print "Joe ainda nao foi descoberto"
			else:							
          			proxobj(x)
		except: print "impossivel"
# ---------------------------------------------------------------
def agent():
	rospy.init_node('agente')

	rospy.Subscriber("questions_keyboard", String, callback2)
	rospy.Subscriber("object_recognition", String, callback1)
	rospy.Subscriber("odom", Odometry, callback)

	rospy.spin()

# ---------------------------------------------------------------
if __name__ == '__main__':
	agent()

